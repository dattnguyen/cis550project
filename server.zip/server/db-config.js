module.exports = {
  user: "admin",
  password: "550group7",
  connectString: "cis550proj.cfot25rjb5mg.us-east-1.rds.amazonaws.com/jeopardy"
};